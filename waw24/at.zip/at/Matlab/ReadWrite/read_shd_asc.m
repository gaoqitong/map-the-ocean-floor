function [ PlotTitle, PlotType, freq, atten, Pos, pressure ] = read_shd_asc( filename )

% Read an ascii shade file

% open the file
fid = fopen( filename, 'r' );
if ( fid == -1 )
    error( 'No shade file with that name exists; you must run a model first' );
end

% read

PlotTitle = fgetl( fid );
PlotType  = fgetl( fid );
freq      = fscanf( fid, '%f', 1 );
Ntheta    = fscanf( fid, '%i', 1 );
Nsd       = fscanf( fid, '%i', 1 );
Nrd       = fscanf( fid, '%i', 1 );
Nrr       = fscanf( fid, '%i', 1 );
atten     = fscanf( fid, '%f', 1 );

Pos.theta    = fscanf( fid, '%f', Ntheta );
Pos.s.depth  = fscanf( fid, '%f', Nsd );
Pos.r.depth  = fscanf( fid, '%f', Nrd );
Pos.r.range  = fscanf( fid, '%f', Nrr );

isd = 1;
for ii = 1:isd
   temp1   = fscanf( fid, '%f', [ 2 * Nrr, Nrd ] );
   ii, size( temp1 )
end

fclose( fid );

% joint real and imaginary parts into a complex matrix

pressure = temp1( 1 : 2 : 2 * Nrr, : )' + 1i * temp1( 2 : 2 : 2 * Nrr, : )';