[ Arr ] = aggregator( Arr, deltat )

% collects arrivals with similar delays
% usage
%    Arr = aggregator( Arr, deltat )
%
% mbp 4/2009
% under construction

for irr = 1 : Nrr
   for ird = 1 : Nrd
      for isd = 1 : Nsd
         
         

   
   for iarr = 1 : Arr.Narr( ir, ird, isd )   % loop over arrivals
      
 
end

